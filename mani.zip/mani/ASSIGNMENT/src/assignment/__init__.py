import os
import json
import time
import pandas as pd
from dotenv import load_dotenv

load_dotenv()
# Reading csv file

df = pd.read_csv(os.getenv("input_path"))
df.head()

# Combining all the columns
df["combined"] = (
    "Abstract: "
    + df["paper_id"]
    + " "
    + df["title"]
    + " "
    + df["abstract"]
    + " "
    + df["publication_year"]
)
df["combined"].head()

from openai import AzureOpenAI

client = AzureOpenAI(
    azure_endpoint=os.getenv("OPENAI_API_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY"),
    api_version="2024-09-01-preview",
)

query = ""
context = df.head().to_json(orient="records")
context
response = client.chat.completions.create(
    model="gpt-4o",  # replace with the model deployment name of your o1-preview, or o1-mini model
    messages=[
        {
            "role": "system",
            "content": "You are a helpful assistant who answers only from the given Context",
        },
        {"role": "user", "content": "Context:" + context + "\n\n Query: " + query},
    ],
    max_completion_tokens=5000,
)
response = response.choices[0].message.con
print(response.model_dump_json(indent=2))
time.sleep(5)
